from django.apps import AppConfig


class EdicionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'edicion'
